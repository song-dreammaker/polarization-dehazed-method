function[L_res]=positive_num(L)

%%ȡ�������������������

[m,n,k]=size(L);
if k==3
 L_res=ones(m,n,k);
for i=1:m
for j=1:n
  for k=1:3
  if L(i,j,k)<=0
      L_res(i,j,k)=0;
  else
       L_res(i,j,k)=L(i,j,k);
  end;
  
  end;
end;
end;
end;
if k==1
 L_res=ones(m,n,1);
for i=1:m
for j=1:n
  if L(i,j)<0
      L_res(i,j)=0;
  else
       L_res(i,j)=L(i,j);
  end;
  
end;
end;
end;
