


 I=im2double(imread('../image/f29.bmp'));
 [I0, I45, I90, I135] = PolarImageSplit(I);

% path='../image/';
% I0=   im2double(imread([ path '0��.jpg']));
% I45=  im2double(imread([ path '45��.jpg']));
% I90=  im2double(imread([ path '90��.jpg']));
% I135= im2double(imread([ path '135��.jpg']));
 tic;
 %% conv 1-4 �ֱ��� 5.5��2��0.05��1.5
 res=polarization_dehazed(I0,I45,I90,I135);
 toc;

 hazeSingle=(I0+I45+I90+I135)/4;
 imshow( [hazeSingle res]);title(['��' srting0  '��ͼ��' ]);


