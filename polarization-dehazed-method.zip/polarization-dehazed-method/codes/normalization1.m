function L_new=normalization1(L)
%%��ͼ����й�һ������
[m,n,k]=size(L);
%%������ߵ㣬������ߵ������

% val=mean(max(variance_img));
% c=2.^(-(floor(255*variance_img)/255*val));
% L_new(:,:,1)=L(:,:,1)./(max_third(1)*2.^(-(floor(255*variance_img)/255*val)));
% L_new(:,:,2)=L(:,:,2)./(max_third(2)*2.^(-(floor(255*variance_img)/255*val)));
% L_new(:,:,3)=L(:,:,3)./(max_third(3)*2.^(-(floor(255*variance_img)/255*val)));

mean_Val=mean(mean(mean(L)));
for i=1:m
    for j=1:n
        for k=1:3
            
         if L(i,j,k)<0
            L(i,j,k)=0;
         end;
         if L(i,j,k)>40*mean_Val %%ԭ����20������
            L(i,j,k)=1;
         end
         
        end;
    end
end;


%%
for k=1:3
    Ls=L(:,:,k);
    [m1,n1]=size(Ls);
    imsize=m1*n1;
    top=reshape(Ls,imsize,1);
    topDark = sort(top, 'descend');
    max_third(k)=topDark(floor(0.0001*imsize));%%ԭ����0.001
end;
%%%
    L_new(:,:,1)=L(:,:,1)./(max_third(1));
    L_new(:,:,2)=L(:,:,2)./(max_third(2));
    L_new(:,:,3)=L(:,:,3)./(max_third(3));
% % % %%10/13
    L_new(:,:,1)=L(:,:,1)./(mean(max(L(:,:,1))));
    L_new(:,:,2)=L(:,:,2)./(mean(max(L(:,:,2))));
    L_new(:,:,3)=L(:,:,3)./(mean(max(L(:,:,3))));
% end;
% if( k==1)
% %%��ͼ����й�һ������
% W = fspecial('gaussian',[5,5],10); 
% L2=L;
% L = imfilter(L, W, 'replicate');
% [m,n]=size(L);
% for i=1:m
%   for j=1:n
%     if L(i,j)>2;
%         L(i,j)=1;
%      
%     end;
%     if L(i,j)<0;
%         L(i,j)=0;
%     end;
%   end;
% end;
% 
% 
% L_new=L2./abs(max(max(L)));
% 
% end;



