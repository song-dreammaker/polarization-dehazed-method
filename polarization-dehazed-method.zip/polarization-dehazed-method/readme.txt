Note that this demo is for the dehzazed paper written in chinses.
The pictures captured by polarized camera are shown in the file named as images.
As we just want to display diffenrent scenes in these images, we only show thumbnail.
If anyone want to use these images, you can address by email:17863931477@163.com.
At last, as the paper is not be published, more information can be obtained until it is accepted.